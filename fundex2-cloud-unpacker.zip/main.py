from flask import Flask, render_template, request, jsonify, send_from_directory
import os
import subprocess
import glob

# 创建 Flask 应用实例
app = Flask(__name__, template_folder='.')

# 指定上传文件保存的目录
UPLOAD_FOLDER = 'apk'

# 定义路由和处理函数，处理文件上传请求
@app.route('/', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        try:
            # 获取上传的文件
            file = request.files['file']
            # 检查文件是否为 APK 文件
            if file and file.filename.endswith('.apk'):
                filename = file.filename
                # 保存文件到指定目录
                file.save(os.path.join(app.root_path, UPLOAD_FOLDER, filename))
                # 安装 APK 文件
                install_apk(filename)
                filename_without_extension = os.path.splitext(filename)[0]
                # 返回成功信息
                return f'APK文件 {filename_without_extension} 上传成功！'
            else:
                # 返回错误信息
                return '无效的APK文件！'
        except Exception as e:
            # 返回异常信息
            return f'发生错误：{str(e)}'
    # 返回上传页面
    return render_template('web.html')

# 定义函数，安装 APK 文件
def install_apk(filename):
    # 构造 adb 命令
    install = f'adb install -r -d {os.path.join(UPLOAD_FOLDER, filename)}'
    # 执行 adb 命令
    result = subprocess.run(install, shell=True, capture_output=True, text=True)

    # 检查命令执行结果
    if result.returncode == 0:
        package = os.path.splitext(filename)[0]
        print(f'APK文件 {package} 安装成功！')
        # 执行日志记录脚本
        subprocess.run(['python', 'tk.py', package])
        return True
    else:
        print(f'APK文件 {package} 安装失败！')
        return False

# 定义路由和处理函数，查询 dex 文件目录
@app.route('/queryDexDirectory', methods=['GET','POST'])
def query_dex_directory():
    # 获取请求参数中的包名
    package_name = request.args.get('package')
    if not package_name:
        # 返回错误信息
        response = {
            'error': '包名不能为空！'
        }
        return jsonify(response), 400
    # 构造 dex 文件路径
    dex_path = os.path.join('dex', package_name + '.zip')
    if os.path.exists(dex_path):
        # 返回 dex 文件目录信息
        response = {
            'exists': True,
            'dexDirectory': dex_path
        }
        return jsonify(response)
    else:
        # 返回错误信息
        response = {
            'exists': False,
            'error': '文件不存在！'
        }
        return jsonify(response), 404

# 定义路由和处理函数，下载 dex 文件
@app.route('/dex/<path:filename>', methods=['GET'])
def download_file(filename):
    return send_from_directory('dex', filename, as_attachment=True)

if __name__ == '__main__':
    # 检查上传目录是否存在，不存在则创建
    if not os.path.exists(UPLOAD_FOLDER):
        os.makedirs(UPLOAD_FOLDER)
    # 启动 Flask 应用
    app.run(host='0.0.0.0', port=1000)
