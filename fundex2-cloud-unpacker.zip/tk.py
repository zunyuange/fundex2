import os
import sys
import subprocess
import re
import json
import xml.etree.ElementTree as ET
import time
import shutil

  # 有问题可加企鹅群交流572240187

def main():
    # 从命令行参数获取包名
    package = sys.argv[1]

    # 定义XML配置文件和手机路径的路径
    xml_path = os.path.abspath('ZhenxiConfig.xml')
    phone_path = '/data/misc/8217b408-39a2-4489-a70e-04e78bea2811/prefs/com.zhenxi.FunDex2/'

    # 解析XML文件并找到JSON配置节点
    tree = ET.parse(xml_path)
    root = tree.getroot()
    config_json_node = root.find(".//string[@name='CONFIG_JSON']")
    config_json_text = config_json_node.text

    # 将JSON配置加载到Python字典中
    data = json.loads(config_json_text)

    # 在配置中更新包名
    data["PACKAGE_NAME"] = package

    # 将更新后的配置转换回JSON字符串
    updated_config_json_text = json.dumps(data)

    # 在XML文件中更新JSON配置
    config_json_node.text = updated_config_json_text
    tree.write(xml_path, encoding='utf-8', xml_declaration=True)

    # 将更新后的XML配置文件推送到手机
    command = f'adb root && adb push {xml_path} {phone_path}'
    subprocess.run(command, shell=True)

    # 在手机上启动应用
    subprocess.run(['adb', 'shell', 'monkey', '-p', package, '1'])

      # 启动多少秒后执行pull dex
    time.sleep(60)

    # 定义dex文件的目录
    dex = f"dex/{package}"
    if not os.path.exists(dex):
        os.makedirs(dex)

    # 从手机获取dex文件列表
    subprocess.run(['adb', 'root'], capture_output=True, text=True)
    result = subprocess.run(['adb', 'shell', f'ls /data/user/0/{package}/*.dex'], capture_output=True, text=True)
    output = result.stdout.strip()
    dex_files = re.findall(r'[^/]+\.dex', output)

    # 将每个dex文件从手机拉到本地dex目录
    for dex_file in dex_files:
     subprocess.run(f'adb pull /data/user/0/{package}/{dex_file} {dex}/{dex_file}', shell=True)

    # 创建dex目录的zip存档
    shutil.make_archive(dex, 'zip', dex)

    # 删除原始dex目录
    shutil.rmtree(dex)

if __name__ == "__main__":
    main()
